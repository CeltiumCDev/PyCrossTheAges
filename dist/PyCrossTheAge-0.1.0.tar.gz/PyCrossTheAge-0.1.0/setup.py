from distutils.core import setup

setup(
    description="Un tutoriel pas comme les autres..",
    author="VitriSnake",
    author_email="vitrisnake@gmail.com",
    name="PyCrossTheAge",
    packages=["pycrosstheages"],
    url="https://matrix.to/#/@vitrisnake-dev:matrix.org",
    version="0.1.0",
)
